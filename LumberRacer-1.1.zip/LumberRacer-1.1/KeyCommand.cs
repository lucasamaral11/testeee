namespace LumberRacer
{
    public enum KeyCommand
    {
        Left, Right
    }
}