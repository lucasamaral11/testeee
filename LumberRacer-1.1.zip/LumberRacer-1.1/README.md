# LumberRacer
A simple program to cheat on Telegram Lumberjack game.

You can see more details about the program on my blog post here:
http://mehrandvd.me/2016/10/30/cheating-telegram-lumberjack/
